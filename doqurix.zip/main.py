"""
Doqurix - Intelligent Document Analysis
Using llama-cpp-python for efficient CPU inference with quantization
Best-in-class RAG implementation
"""

import os
import sys
from pathlib import Path
from llama_cpp import Llama
from sentence_transformers import SentenceTransformer, CrossEncoder
import chromadb
from chromadb.config import Settings
import PyPDF2
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import threading
from rank_bm25 import BM25Okapi
import numpy as np
import re
from huggingface_hub import hf_hub_download
import urllib.request
import time
import hashlib
import json
from datetime import datetime, timedelta


# ============================================================================
# LICENSE MANAGEMENT SYSTEM
# ============================================================================

class LicenseManager:
    """Manages trial period and license key validation"""
    
    # Secret key for license generation (keep this secure!)
    _SECRET_KEY = "DQX2025-UNIPER-SECURE-KEY"
    _TRIAL_DAYS = 30
    
    # Valid license keys (pre-generated)
    # Format: DQRX-XXXX-XXXX-XXXX
    VALID_KEYS = [
        "DQRX-7K9M-P2XN-4HTL",
        "DQRX-3FBW-8QYC-J6VR",
        "DQRX-9LDH-5MKS-2ATP",
        "DQRX-6NWT-R4GZ-8CVE",
        "DQRX-1YPJ-X7BF-Q3UM",
        "DQRX-4KCR-2HVL-9DWN",
        "DQRX-8MSG-6TYP-Z5JB",
        "DQRX-2QXA-K9FE-7LHC",
        "DQRX-5VBN-3DWT-R8YK",
        "DQRX-7ZJL-P4MQ-1SGF",
        "DQRX-9CTH-6XVR-4KBW",
        "DQRX-3PME-Y8NJ-2FAL",
        "DQRX-6WKS-1QDC-5TXH",
        "DQRX-4LBV-7GRZ-9MYN",
        "DQRX-8FXP-2KCJ-3WQT",
        "DQRX-1DHY-5SLM-6VBG",
        "DQRX-9NRA-4ZWK-8PFC",
        "DQRX-2TCM-X6HQ-7JLS",
        "DQRX-5GVE-9BYN-1KDW",
        "DQRX-7QJZ-3FPT-4XMH",
    ]
    
    def __init__(self):
        # License data stored in user's AppData
        appdata = Path(os.environ.get('LOCALAPPDATA', os.path.expanduser('~')))
        self.license_dir = appdata / "Doqurix"
        self.license_dir.mkdir(exist_ok=True)
        self.license_file = self.license_dir / ".license"
        self.trial_file = self.license_dir / ".trial"
    
    def _get_machine_id(self):
        """Generate a unique machine identifier"""
        import platform
        machine_info = f"{platform.node()}-{platform.machine()}-{os.environ.get('USERNAME', 'user')}"
        return hashlib.sha256(machine_info.encode()).hexdigest()[:16]
    
    def _hash_data(self, data):
        """Create a hash for data integrity"""
        return hashlib.sha256(f"{data}{self._SECRET_KEY}".encode()).hexdigest()
    
    def start_trial(self):
        """Start a new trial period"""
        machine_id = self._get_machine_id()
        start_date = datetime.now().isoformat()
        
        trial_data = {
            "machine_id": machine_id,
            "start_date": start_date,
            "hash": self._hash_data(f"{machine_id}{start_date}")
        }
        
        with open(self.trial_file, 'w') as f:
            json.dump(trial_data, f)
        
        return self._TRIAL_DAYS
    
    def get_trial_status(self):
        """
        Check trial status
        Returns: (is_valid, days_remaining, message)
        """
        if not self.trial_file.exists():
            # First run - start trial
            days = self.start_trial()
            return True, days, f"Trial started! {days} days remaining."
        
        try:
            with open(self.trial_file, 'r') as f:
                trial_data = json.load(f)
            
            # Verify data integrity
            machine_id = self._get_machine_id()
            expected_hash = self._hash_data(f"{trial_data['machine_id']}{trial_data['start_date']}")
            
            if trial_data['hash'] != expected_hash or trial_data['machine_id'] != machine_id:
                return False, 0, "Trial data corrupted or transferred. Please enter a license key."
            
            # Calculate remaining days
            start_date = datetime.fromisoformat(trial_data['start_date'])
            elapsed = datetime.now() - start_date
            remaining = self._TRIAL_DAYS - elapsed.days
            
            if remaining > 0:
                return True, remaining, f"Trial: {remaining} days remaining"
            else:
                return False, 0, "Trial period expired. Please enter a license key to continue."
            
        except (json.JSONDecodeError, KeyError, ValueError):
            return False, 0, "Trial data corrupted. Please enter a license key."
    
    def validate_license_key(self, key):
        """
        Validate a license key
        Returns: (is_valid, message)
        """
        # Normalize key format
        key = key.strip().upper().replace(" ", "-")
        
        # Check format
        if not re.match(r'^DQRX-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$', key):
            return False, "Invalid key format. Expected: DQRX-XXXX-XXXX-XXXX"
        
        # Check against valid keys
        if key in self.VALID_KEYS:
            self._save_license(key)
            return True, "License activated successfully! Thank you for your purchase."
        
        return False, "Invalid license key. Please check and try again."
    
    def _save_license(self, key):
        """Save activated license"""
        machine_id = self._get_machine_id()
        activation_date = datetime.now().isoformat()
        
        license_data = {
            "key": key,
            "machine_id": machine_id,
            "activation_date": activation_date,
            "hash": self._hash_data(f"{key}{machine_id}{activation_date}")
        }
        
        with open(self.license_file, 'w') as f:
            json.dump(license_data, f)
    
    def check_license(self):
        """
        Check if software is licensed
        Returns: (is_licensed, message, days_remaining)
        - days_remaining is -1 if not licensed, otherwise days until expiration
        """
        if not self.license_file.exists():
            return False, "Not licensed", -1
        
        try:
            with open(self.license_file, 'r') as f:
                license_data = json.load(f)
            
            machine_id = self._get_machine_id()
            expected_hash = self._hash_data(
                f"{license_data['key']}{license_data['machine_id']}{license_data['activation_date']}"
            )
            
            if license_data['hash'] != expected_hash:
                return False, "License data corrupted", -1
            
            if license_data['machine_id'] != machine_id:
                return False, "License not valid for this machine", -1
            
            if license_data['key'] not in self.VALID_KEYS:
                return False, "Invalid license key", -1
            
            # Check if license has expired (1 year = 365 days)
            activation_date = datetime.fromisoformat(license_data['activation_date'])
            days_since_activation = (datetime.now() - activation_date).days
            license_days_remaining = 365 - days_since_activation
            
            if license_days_remaining <= 0:
                return False, "License expired (1 year limit reached)", 0
            
            return True, "Licensed", license_days_remaining
            
        except (json.JSONDecodeError, KeyError):
            return False, "License data corrupted", -1
    
    def get_status(self):
        """
        Get overall license status
        Returns: (can_run, is_trial, days_remaining, message)
        - For licensed users: days_remaining = days until license expires
        - For trial users: days_remaining = days left in trial
        """
        # First check if licensed
        is_licensed, license_msg, license_days = self.check_license()
        if is_licensed:
            if license_days <= 30:
                return True, False, license_days, f"✓ Licensed ({license_days} days left)"
            else:
                return True, False, license_days, "✓ Licensed"
        
        # If license expired, show that message
        if license_msg == "License expired (1 year limit reached)":
            return False, False, 0, license_msg
        
        # Check trial
        trial_valid, days_remaining, trial_msg = self.get_trial_status()
        if trial_valid:
            return True, True, days_remaining, trial_msg
        
        # Neither licensed nor valid trial
        return False, False, 0, trial_msg


class LicenseDialog:
    """Dialog for entering license key"""
    
    def __init__(self, parent, license_manager, days_remaining=0, is_expired=False):
        self.result = False
        self.license_manager = license_manager
        
        self.dialog = tk.Toplevel(parent)
        self.dialog.title("Doqurix - License Activation")
        self.dialog.geometry("500x400")
        self.dialog.resizable(False, False)
        self.dialog.transient(parent)
        self.dialog.grab_set()
        
        # Center the dialog
        self.dialog.update_idletasks()
        x = (self.dialog.winfo_screenwidth() // 2) - 250
        y = (self.dialog.winfo_screenheight() // 2) - 200
        self.dialog.geometry(f"+{x}+{y}")
        
        self.dialog.configure(bg='#f5f5f5')
        
        # Main frame
        main_frame = tk.Frame(self.dialog, bg='#f5f5f5', padx=30, pady=20)
        main_frame.pack(fill='both', expand=True)
        
        # Logo/Title
        title_label = tk.Label(main_frame, text="📚 Doqurix",
                               font=('Segoe UI', 24, 'bold'),
                               bg='#f5f5f5', fg='#2c3e50')
        title_label.pack(pady=(0, 5))
        
        subtitle = tk.Label(main_frame, text="License Activation",
                           font=('Segoe UI', 12),
                           bg='#f5f5f5', fg='#7f8c8d')
        subtitle.pack(pady=(0, 20))
        
        # Status message
        if is_expired:
            status_text = "⚠️ Your trial period has expired."
            status_color = '#e74c3c'
        else:
            status_text = f"📅 Trial: {days_remaining} days remaining"
            status_color = '#27ae60'
        
        status_label = tk.Label(main_frame, text=status_text,
                               font=('Segoe UI', 11),
                               bg='#f5f5f5', fg=status_color)
        status_label.pack(pady=(0, 20))
        
        # License key entry
        key_frame = tk.Frame(main_frame, bg='#f5f5f5')
        key_frame.pack(fill='x', pady=10)
        
        tk.Label(key_frame, text="Enter License Key:",
                font=('Segoe UI', 10, 'bold'),
                bg='#f5f5f5').pack(anchor='w')
        
        self.key_entry = tk.Entry(key_frame, font=('Consolas', 14),
                                  width=30, justify='center')
        self.key_entry.pack(fill='x', pady=(5, 0), ipady=8)
        self.key_entry.insert(0, "DQRX-XXXX-XXXX-XXXX")
        self.key_entry.bind('<FocusIn>', self._clear_placeholder)
        self.key_entry.bind('<Return>', lambda e: self._activate())
        
        # Message label
        self.message_label = tk.Label(main_frame, text="",
                                      font=('Segoe UI', 9),
                                      bg='#f5f5f5', fg='#e74c3c')
        self.message_label.pack(pady=10)
        
        # Buttons
        button_frame = tk.Frame(main_frame, bg='#f5f5f5')
        button_frame.pack(pady=20)
        
        activate_btn = tk.Button(button_frame, text="🔑 Activate License",
                                 command=self._activate,
                                 font=('Segoe UI', 10, 'bold'),
                                 bg='#27ae60', fg='white',
                                 activebackground='#229954',
                                 relief='flat', padx=20, pady=10,
                                 cursor='hand2')
        activate_btn.pack(side='left', padx=5)
        
        if not is_expired:
            continue_btn = tk.Button(button_frame, text="Continue Trial",
                                     command=self._continue_trial,
                                     font=('Segoe UI', 10),
                                     bg='#3498db', fg='white',
                                     activebackground='#2980b9',
                                     relief='flat', padx=20, pady=10,
                                     cursor='hand2')
            continue_btn.pack(side='left', padx=5)
        
        exit_btn = tk.Button(button_frame, text="Exit",
                            command=self._exit,
                            font=('Segoe UI', 10),
                            bg='#95a5a6', fg='white',
                            activebackground='#7f8c8d',
                            relief='flat', padx=20, pady=10,
                            cursor='hand2')
        exit_btn.pack(side='left', padx=5)
        
        # Purchase info
        info_label = tk.Label(main_frame, 
                             text="Need a license? Contact: sales@doqurix.com",
                             font=('Segoe UI', 9, 'italic'),
                             bg='#f5f5f5', fg='#7f8c8d')
        info_label.pack(side='bottom', pady=10)
        
        # Handle window close
        self.dialog.protocol("WM_DELETE_WINDOW", self._exit)
    
    def _clear_placeholder(self, event):
        if self.key_entry.get() == "DQRX-XXXX-XXXX-XXXX":
            self.key_entry.delete(0, 'end')
    
    def _activate(self):
        key = self.key_entry.get()
        is_valid, message = self.license_manager.validate_license_key(key)
        
        if is_valid:
            self.message_label.config(text=message, fg='#27ae60')
            self.result = True
            self.dialog.after(1500, self.dialog.destroy)
        else:
            self.message_label.config(text=message, fg='#e74c3c')
    
    def _continue_trial(self):
        self.result = True
        self.dialog.destroy()
    
    def _exit(self):
        self.result = False
        self.dialog.destroy()
    
    def show(self):
        self.dialog.wait_window()
        return self.result


class DownloadProgressWindow:
    """A progress window that shows download status to users"""
    
    def __init__(self, parent, title="Downloading..."):
        self.window = tk.Toplevel(parent)
        self.window.title(title)
        self.window.geometry("500x200")
        self.window.resizable(False, False)
        self.window.transient(parent)
        self.window.grab_set()
        
        # Center the window
        self.window.update_idletasks()
        x = (self.window.winfo_screenwidth() // 2) - (250)
        y = (self.window.winfo_screenheight() // 2) - (100)
        self.window.geometry(f"+{x}+{y}")
        
        # Configure style
        self.window.configure(bg='#f5f5f5')
        
        # Main frame
        main_frame = tk.Frame(self.window, bg='#f5f5f5', padx=30, pady=20)
        main_frame.pack(fill='both', expand=True)
        
        # Title label
        self.title_label = tk.Label(main_frame, text="⏳ First Time Setup", 
                                    font=('Segoe UI', 14, 'bold'),
                                    bg='#f5f5f5', fg='#2c3e50')
        self.title_label.pack(pady=(0, 10))
        
        # Status label
        self.status_label = tk.Label(main_frame, text="Preparing download...", 
                                     font=('Segoe UI', 10),
                                     bg='#f5f5f5', fg='#555')
        self.status_label.pack(pady=(0, 15))
        
        # Progress bar
        self.progress_var = tk.DoubleVar()
        self.progress_bar = ttk.Progressbar(main_frame, variable=self.progress_var,
                                            maximum=100, length=400, mode='determinate')
        self.progress_bar.pack(pady=(0, 10))
        
        # Percentage and size label
        self.detail_label = tk.Label(main_frame, text="0% - Calculating...", 
                                     font=('Segoe UI', 9),
                                     bg='#f5f5f5', fg='#777')
        self.detail_label.pack()
        
        # ETA label
        self.eta_label = tk.Label(main_frame, text="", 
                                  font=('Segoe UI', 9),
                                  bg='#f5f5f5', fg='#777')
        self.eta_label.pack()
        
        self.start_time = None
        self.window.protocol("WM_DELETE_WINDOW", lambda: None)  # Prevent closing
        
    def update_progress(self, downloaded, total, speed=None):
        """Update the progress bar and labels"""
        if total > 0:
            percent = (downloaded / total) * 100
            self.progress_var.set(percent)
            
            # Format sizes
            downloaded_mb = downloaded / (1024 * 1024)
            total_mb = total / (1024 * 1024)
            
            self.detail_label.config(text=f"{percent:.1f}% - {downloaded_mb:.1f} MB / {total_mb:.1f} MB")
            
            # Calculate ETA
            if self.start_time and downloaded > 0:
                elapsed = time.time() - self.start_time
                if elapsed > 0:
                    speed_calc = downloaded / elapsed
                    remaining = total - downloaded
                    eta_seconds = remaining / speed_calc if speed_calc > 0 else 0
                    
                    if eta_seconds < 60:
                        eta_str = f"{int(eta_seconds)} seconds"
                    elif eta_seconds < 3600:
                        eta_str = f"{int(eta_seconds // 60)} min {int(eta_seconds % 60)} sec"
                    else:
                        eta_str = f"{int(eta_seconds // 3600)} hr {int((eta_seconds % 3600) // 60)} min"
                    
                    speed_mbps = (speed_calc * 8) / (1024 * 1024)
                    self.eta_label.config(text=f"Speed: {speed_mbps:.1f} Mbps • ETA: {eta_str}")
        else:
            self.progress_bar.config(mode='indeterminate')
            self.progress_bar.start(10)
            
        self.window.update()
    
    def set_status(self, status):
        """Update status text"""
        self.status_label.config(text=status)
        self.window.update()
    
    def set_title(self, title):
        """Update title text"""
        self.title_label.config(text=title)
        self.window.update()
    
    def start_timer(self):
        """Start the download timer for ETA calculation"""
        self.start_time = time.time()
    
    def set_indeterminate(self):
        """Set progress bar to indeterminate mode"""
        self.progress_bar.config(mode='indeterminate')
        self.progress_bar.start(10)
        self.detail_label.config(text="Please wait...")
        self.eta_label.config(text="")
        self.window.update()
    
    def close(self):
        """Close the progress window"""
        self.window.grab_release()
        self.window.destroy()

class DocumentQAApp:
    def __init__(self, trial_info=None):
        self.app_dir = Path(__file__).parent
        self.trial_info = trial_info  # (is_trial, days_remaining)
        
        # Use AppData for user-writable directories (works in Program Files)
        appdata = Path(os.environ.get('LOCALAPPDATA', os.path.expanduser('~')))
        self.user_data_dir = appdata / "Doqurix"
        self.user_data_dir.mkdir(exist_ok=True)
        
        # Models bundled with app, data stored in user directory
        self.models_dir = self.app_dir / "models"
        self.data_dir = self.user_data_dir / "data"
        self.vector_store_dir = self.data_dir / "vector_store"
        
        # Create directories
        self.models_dir.mkdir(exist_ok=True)
        self.data_dir.mkdir(exist_ok=True)
        self.vector_store_dir.mkdir(exist_ok=True)
        
        # BM25 index
        self.bm25 = None
        self.bm25_corpus = []
        self.current_contexts = []
        
        # Progress window reference
        self.progress_window = None
        
        # Setup GUI first
        self.setup_gui()
        
        # Initialize models in background
        self.models_loaded = False
        threading.Thread(target=self.load_models, daemon=True).start()
    
    def show_progress_window(self, title="Setting Up..."):
        """Show progress window on main thread"""
        if self.progress_window is None:
            self.progress_window = DownloadProgressWindow(self.root, title)
        return self.progress_window
    
    def close_progress_window(self):
        """Close progress window safely"""
        if self.progress_window:
            self.progress_window.close()
            self.progress_window = None
    
    def load_models(self):
        """Load all models in background"""
        try:
            self.update_status("🔄 Loading AI engine...")
            
            # Check if any models need downloading
            needs_download = self.check_models_need_download()
            
            if needs_download:
                # Show progress window on main thread
                self.root.after(0, lambda: self.show_progress_window("First Time Setup"))
                self.root.after(100, self._continue_loading)
            else:
                self._load_all_models()
                
        except Exception as e:
            self.root.after(0, self.close_progress_window)
            self.update_status(f"❌ Error: {str(e)}")
            self.root.after(0, lambda: messagebox.showerror("Error", 
                f"Failed to load models:\n{str(e)}\n\nMake sure you have a good internet connection"))
    
    def check_models_need_download(self):
        """Check if any models need to be downloaded"""
        model_path = self.models_dir / "qwen2.5-1.5b-instruct-q4_k_m.gguf"
        
        # Check for the main GGUF model
        if not model_path.exists():
            return True
        
        # Check for sentence transformers cache
        cache_dir = Path(os.environ.get('HF_HOME', Path.home() / '.cache' / 'huggingface'))
        st_cache = cache_dir / 'hub'
        
        # If cache doesn't exist or is empty, models will need to download
        if not st_cache.exists():
            return True
            
        return False
    
    def _continue_loading(self):
        """Continue loading in background after progress window is shown"""
        threading.Thread(target=self._load_all_models, daemon=True).start()
    
    def _load_all_models(self):
        """Actually load all the models"""
        try:
            self.init_llm()
            self.init_embeddings()
            self.init_reranker()
            self.init_vector_db()
            
            self.root.after(0, self.close_progress_window)
            self.models_loaded = True
            self.update_status("✓ Ready! Upload documents and start asking questions.")
            self.root.after(0, lambda: self.ask_btn.config(state='normal'))
            self.root.after(0, lambda: self.upload_btn.config(state='normal'))
            self.root.after(0, lambda: self.summary_btn.config(state='normal'))
            # Enable delete button only if there are documents
            if self.doc_listbox.size() > 0:
                self.root.after(0, lambda: self.delete_btn.config(state='normal'))
        except Exception as e:
            self.root.after(0, self.close_progress_window)
            self.update_status(f"❌ Error: {str(e)}")
            self.root.after(0, lambda: messagebox.showerror("Error", 
                f"Failed to load models:\n{str(e)}\n\nMake sure you have a good internet connection"))
    
    def init_llm(self):
        """Initialize LLM with quantization via llama.cpp"""
        self.update_status("📥 Checking AI model...")
        
        # Download quantized GGUF model from HuggingFace
        model_path = self.models_dir / "qwen2.5-1.5b-instruct-q4_k_m.gguf"
        
        if not model_path.exists():
            self.update_status("⬇️ Downloading AI model...")
            
            # Update progress window
            if self.progress_window:
                self.root.after(0, lambda: self.progress_window.set_title("⬇️ Downloading AI Model"))
                self.root.after(0, lambda: self.progress_window.set_status("Downloading language model (~1 GB)..."))
                self.root.after(0, lambda: self.progress_window.start_timer())
            
            try:
                # Use callback for progress tracking
                def progress_callback(progress):
                    """Callback for download progress from huggingface_hub"""
                    if self.progress_window and hasattr(progress, 'downloaded') and hasattr(progress, 'total'):
                        self.root.after(0, lambda d=progress.downloaded, t=progress.total: 
                                       self.progress_window.update_progress(d, t))
                
                downloaded_path = hf_hub_download(
                    repo_id="Qwen/Qwen2.5-1.5B-Instruct-GGUF",
                    filename="qwen2.5-1.5b-instruct-q4_k_m.gguf",
                    local_dir=str(self.models_dir)
                )
                model_path = Path(downloaded_path)
            except Exception as e:
                self.update_status(f"Error downloading: {str(e)}")
                raise
        
        self.update_status("🧠 Loading AI engine into memory...")
        if self.progress_window:
            self.root.after(0, lambda: self.progress_window.set_title("🧠 Loading AI Engine"))
            self.root.after(0, lambda: self.progress_window.set_status("Loading model into memory..."))
            self.root.after(0, lambda: self.progress_window.set_indeterminate())
        
        # Load with llama.cpp (optimized for CPU with max performance)
        self.llm = Llama(
            model_path=str(model_path),
            n_ctx=3072,  # Increased context window
            n_threads=os.cpu_count() or 4,  # Use all CPU cores
            n_batch=512,  # Larger batch for faster processing
            n_gpu_layers=0,  # CPU only
            verbose=False,
            use_mlock=True  # Lock model in RAM for faster access
        )
        
        self.update_status("✓ AI engine loaded successfully")
    
    def init_embeddings(self):
        """Initialize faster embedding model"""
        self.update_status("📥 Loading search engine...")
        
        if self.progress_window:
            self.root.after(0, lambda: self.progress_window.set_title("📥 Loading Search Engine"))
            self.root.after(0, lambda: self.progress_window.set_status("Downloading embedding model..."))
            self.root.after(0, lambda: self.progress_window.set_indeterminate())
        
        # Using faster, smaller embedding model
        self.embedder = SentenceTransformer('all-MiniLM-L6-v2')
        self.update_status("✓ Embeddings loaded")
    
    def init_reranker(self):
        """Initialize faster reranker"""
        self.update_status("📥 Loading ranking engine...")
        
        if self.progress_window:
            self.root.after(0, lambda: self.progress_window.set_title("📥 Loading Ranking Engine"))
            self.root.after(0, lambda: self.progress_window.set_status("Downloading reranker model..."))
            self.root.after(0, lambda: self.progress_window.set_indeterminate())
        
        # Using smaller, faster reranker
        self.reranker = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2')
        self.update_status("✓ Reranker loaded")
    
    def init_vector_db(self):
        """Initialize ChromaDB"""
        self.update_status("📥 Initializing vector database...")
        
        if self.progress_window:
            self.root.after(0, lambda: self.progress_window.set_title("📥 Initializing Database"))
            self.root.after(0, lambda: self.progress_window.set_status("Setting up vector database..."))
            self.root.after(0, lambda: self.progress_window.set_indeterminate())
        
        self.chroma_client = chromadb.Client(Settings(
            persist_directory=str(self.vector_store_dir),
            anonymized_telemetry=False
        ))
        
        try:
            self.collection = self.chroma_client.get_collection("documents")
            self.rebuild_bm25_index()
            doc_count = len(self.collection.get()['documents'])
            if doc_count > 0:
                self.update_status(f"✓ Database ready ({doc_count} chunks)")
        except:
            self.collection = self.chroma_client.create_collection("documents")
            self.update_status("✓ Database ready")
    
    def rebuild_bm25_index(self):
        """Rebuild BM25 index"""
        all_docs = self.collection.get()
        if all_docs['documents']:
            self.bm25_corpus = all_docs['documents']
            tokenized_corpus = [doc.lower().split() for doc in self.bm25_corpus]
            self.bm25 = BM25Okapi(tokenized_corpus)
    
    def setup_gui(self):
        """Create professional GUI"""
        self.root = tk.Tk()
        self.root.title("Doqurix")
        self.root.geometry("1400x800")
        self.root.configure(bg='#f0f0f0')
        
        # Initialize mode variable after root window is created
        self.rag_mode = tk.StringVar(value="basic")  # Default to basic (faster)
        
        # Create menu bar
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        # Help menu
        help_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Help", menu=help_menu)
        help_menu.add_command(label="🔑 Activate License", command=self.show_license_dialog)
        help_menu.add_separator()
        help_menu.add_command(label="About Doqurix", command=self.show_about)
        
        # Header
        header = tk.Frame(self.root, bg='#2c3e50', height=90)
        header.pack(fill='x', side='top')
        header.pack_propagate(False)
        
        title_frame = tk.Frame(header, bg='#2c3e50')
        title_frame.pack(expand=True)
        
        title = tk.Label(title_frame, text="📚 Doqurix", 
                        font=('Segoe UI', 22, 'bold'), 
                        bg='#2c3e50', fg='white')
        title.pack()
        
        subtitle = tk.Label(title_frame, text="Intelligent Document Analysis • Smart Search • Context Highlighting", 
                           font=('Segoe UI', 10), 
                           bg='#2c3e50', fg='#ecf0f1')
        subtitle.pack()
        
        # Trial/License indicator in header (clickable)
        if self.trial_info and self.trial_info[0]:  # is_trial
            days = self.trial_info[1]
            if days <= 7:
                trial_color = '#e74c3c'  # Red for last week
            elif days <= 14:
                trial_color = '#f39c12'  # Orange for last 2 weeks
            else:
                trial_color = '#27ae60'  # Green
            
            self.trial_label = tk.Label(header, text=f"⏱️ Trial: {days} days left (Click to activate)",
                                  font=('Segoe UI', 9, 'bold'),
                                  bg='#2c3e50', fg=trial_color,
                                  cursor='hand2')
            self.trial_label.place(relx=0.98, rely=0.5, anchor='e')
            self.trial_label.bind('<Button-1>', lambda e: self.show_license_dialog())
        elif self.trial_info:
            self.trial_label = tk.Label(header, text="✓ Licensed",
                                     font=('Segoe UI', 9, 'bold'),
                                     bg='#2c3e50', fg='#27ae60')
            self.trial_label.place(relx=0.98, rely=0.5, anchor='e')
        
        # Main container
        main_container = tk.Frame(self.root, bg='#f0f0f0')
        main_container.pack(fill='both', expand=True, padx=20, pady=15)
        
        # Left panel - Documents (25%)
        left_panel = tk.Frame(main_container, bg='white', relief='solid', bd=1)
        left_panel.pack(side='left', fill='both', expand=False, padx=(0, 10))
        left_panel.config(width=280)
        
        left_header = tk.Frame(left_panel, bg='#3498db', height=45)
        left_header.pack(fill='x')
        left_header.pack_propagate(False)
        
        tk.Label(left_header, text="📁 Documents", 
                font=('Segoe UI', 13, 'bold'), 
                bg='#3498db', fg='white').pack(pady=10)
        
        upload_frame = tk.Frame(left_panel, bg='white')
        upload_frame.pack(pady=15, padx=12)
        
        self.upload_btn = tk.Button(upload_frame, text="➕ Upload PDF",
                                    command=self.upload_document,
                                    font=('Segoe UI', 10, 'bold'),
                                    bg='#3498db', fg='white',
                                    activebackground='#2980b9',
                                    relief='flat', padx=20, pady=10,
                                    cursor='hand2', state='disabled',
                                    borderwidth=0)
        self.upload_btn.pack(pady=(0, 5))
        
        self.delete_btn = tk.Button(upload_frame, text="🗑️ Remove Selected",
                                    command=self.delete_document,
                                    font=('Segoe UI', 9),
                                    bg='#e74c3c', fg='white',
                                    activebackground='#c0392b',
                                    relief='flat', padx=15, pady=6,
                                    cursor='hand2', state='disabled',
                                    borderwidth=0)
        self.delete_btn.pack()
        
        self.doc_count_label = tk.Label(left_panel, text="Documents: 0", 
                                       font=('Segoe UI', 9, 'italic'), 
                                       bg='white', fg='#7f8c8d')
        self.doc_count_label.pack(pady=(0, 8))
        
        list_frame = tk.Frame(left_panel, bg='white')
        list_frame.pack(fill='both', expand=True, padx=12, pady=(0, 12))
        
        scrollbar = tk.Scrollbar(list_frame)
        scrollbar.pack(side='right', fill='y')
        
        self.doc_listbox = tk.Listbox(list_frame, yscrollcommand=scrollbar.set,
                                      font=('Segoe UI', 9),
                                      relief='flat', bd=0,
                                      highlightthickness=1,
                                      highlightcolor='#3498db',
                                      selectbackground='#e8f4f8')
        self.doc_listbox.pack(side='left', fill='both', expand=True)
        scrollbar.config(command=self.doc_listbox.yview)
        
        # Middle panel - Q&A (40%)
        middle_panel = tk.Frame(main_container, bg='white', relief='solid', bd=1)
        middle_panel.pack(side='left', fill='both', expand=True, padx=(0, 10))
        
        middle_header = tk.Frame(middle_panel, bg='#27ae60', height=45)
        middle_header.pack(fill='x')
        middle_header.pack_propagate(False)
        
        tk.Label(middle_header, text="💬 Q&A", 
                font=('Segoe UI', 13, 'bold'), 
                bg='#27ae60', fg='white').pack(pady=10)
        
        # Question section
        question_frame = tk.Frame(middle_panel, bg='white')
        question_frame.pack(fill='x', padx=15, pady=15)
        
        tk.Label(question_frame, text="Your Question:", 
                font=('Segoe UI', 10, 'bold'), 
                bg='white').pack(anchor='w')
        
        self.question_entry = scrolledtext.ScrolledText(question_frame, 
                                                        height=3,
                                                        font=('Segoe UI', 10),
                                                        wrap='word',
                                                        relief='solid', bd=1,
                                                        bg='#fafafa',
                                                        padx=8, pady=8)
        self.question_entry.pack(fill='x', pady=(5, 0))
        
        # Mode selector
        mode_frame = tk.Frame(question_frame, bg='white')
        mode_frame.pack(pady=10, anchor='w')
        
        tk.Label(mode_frame, text="Search Mode:", 
                font=('Segoe UI', 9, 'bold'), 
                bg='white', fg='#34495e').pack(side='left', padx=(0, 10))
        
        basic_radio = tk.Radiobutton(mode_frame, text="⚡ Quick (Faster response)", 
                                     variable=self.rag_mode, value="basic",
                                     font=('Segoe UI', 9),
                                     bg='white', activebackground='white',
                                     cursor='hand2')
        basic_radio.pack(side='left', padx=5)
        
        advanced_radio = tk.Radiobutton(mode_frame, text="🎯 Detailed (More comprehensive)", 
                                       variable=self.rag_mode, value="advanced",
                                       font=('Segoe UI', 9),
                                       bg='white', activebackground='white',
                                       cursor='hand2')
        advanced_radio.pack(side='left', padx=5)
        
        # Action buttons
        action_frame = tk.Frame(question_frame, bg='white')
        action_frame.pack(pady=10)
        
        self.ask_btn = tk.Button(action_frame, text="🔍 Answer Question",
                                command=lambda: self.ask_question_thread('answer'),
                                font=('Segoe UI', 10, 'bold'),
                                bg='#27ae60', fg='white',
                                activebackground='#229954',
                                relief='flat', padx=20, pady=10,
                                cursor='hand2', state='disabled')
        self.ask_btn.pack(side='left', padx=5)
        
        self.summary_btn = tk.Button(action_frame, text="📝 Summarize",
                                     command=lambda: self.ask_question_thread('summarize'),
                                     font=('Segoe UI', 10, 'bold'),
                                     bg='#e67e22', fg='white',
                                     activebackground='#d35400',
                                     relief='flat', padx=20, pady=10,
                                     cursor='hand2', state='disabled')
        self.summary_btn.pack(side='left', padx=5)
        
        # Answer section
        answer_frame = tk.Frame(middle_panel, bg='white')
        answer_frame.pack(fill='both', expand=True, padx=15, pady=(0, 15))
        
        tk.Label(answer_frame, text="📝 Answer:", 
                font=('Segoe UI', 10, 'bold'), 
                bg='white').pack(anchor='w')
        
        self.answer_text = scrolledtext.ScrolledText(answer_frame,
                                                     font=('Segoe UI', 10),
                                                     wrap='word',
                                                     relief='solid', bd=1,
                                                     bg='#f9f9f9',
                                                     padx=12, pady=12)
        self.answer_text.pack(fill='both', expand=True, pady=(5, 0))
        
        # Right panel - Context Viewer (35%)
        right_panel = tk.Frame(main_container, bg='white', relief='solid', bd=1)
        right_panel.pack(side='right', fill='both', expand=True)
        
        right_header = tk.Frame(right_panel, bg='#9b59b6', height=45)
        right_header.pack(fill='x')
        right_header.pack_propagate(False)
        
        tk.Label(right_header, text="🔍 Matched Context", 
                font=('Segoe UI', 13, 'bold'), 
                bg='#9b59b6', fg='white').pack(pady=10)
        
        context_frame = tk.Frame(right_panel, bg='white')
        context_frame.pack(fill='both', expand=True, padx=15, pady=15)
        
        tk.Label(context_frame, text="Relevant sections with keyword highlighting:", 
                font=('Segoe UI', 9, 'italic'), 
                bg='white', fg='#7f8c8d').pack(anchor='w', pady=(0, 5))
        
        self.context_text = scrolledtext.ScrolledText(context_frame,
                                                      font=('Segoe UI', 9),
                                                      wrap='word',
                                                      relief='solid', bd=1,
                                                      bg='#fff9e6',
                                                      padx=12, pady=12)
        self.context_text.pack(fill='both', expand=True)
        
        # Configure tags
        self.context_text.tag_config('highlight', background='#ffeb3b', foreground='#000')
        self.context_text.tag_config('source', font=('Segoe UI', 9, 'bold'), foreground='#2c3e50')
        
        # Status bar
        status_frame = tk.Frame(self.root, bg='#34495e', height=32)
        status_frame.pack(fill='x', side='bottom')
        status_frame.pack_propagate(False)
        
        self.status_label = tk.Label(status_frame, text="🔄 Initializing...", 
                                     font=('Segoe UI', 9),
                                     bg='#34495e', fg='#ecf0f1',
                                     anchor='w', padx=15)
        self.status_label.pack(fill='x', pady=6)
    
    def show_license_dialog(self):
        """Show license activation dialog"""
        license_manager = LicenseManager()
        
        # Check current status
        is_licensed, _, _ = license_manager.check_license()
        
        if is_licensed:
            messagebox.showinfo("Already Licensed", 
                "Doqurix is already activated!\n\nThank you for your purchase.")
            return
        
        # Get trial status
        trial_valid, days_remaining, _ = license_manager.get_trial_status()
        
        # Show dialog
        dialog = LicenseDialog(self.root, license_manager, 
                              days_remaining=days_remaining, 
                              is_expired=not trial_valid)
        result = dialog.show()
        
        if result:
            # Check if license was activated
            is_licensed, _, _ = license_manager.check_license()
            if is_licensed:
                # Update the trial label to show licensed
                if hasattr(self, 'trial_label'):
                    self.trial_label.config(text="✓ Licensed", fg='#27ae60', cursor='arrow')
                    self.trial_label.unbind('<Button-1>')
                messagebox.showinfo("Success", 
                    "License activated successfully!\n\nThank you for purchasing Doqurix.")
    
    def show_about(self):
        """Show about dialog"""
        license_manager = LicenseManager()
        is_licensed, _, _ = license_manager.check_license()
        
        if is_licensed:
            status = "Licensed Version"
        else:
            trial_valid, days, _ = license_manager.get_trial_status()
            if trial_valid:
                status = f"Trial Version ({days} days remaining)"
            else:
                status = "Trial Expired"
        
        about_text = f"""Doqurix v1.0.0

Intelligent Document Analysis
Smart Search • Context Highlighting

Status: {status}

Powered by:
• Advanced AI Language Model
• RAG Pipeline Technology

© 2025 Doqurix. All rights reserved.

Contact: sales@doqurix.com"""
        
        messagebox.showinfo("About Doqurix", about_text)
    
    def update_status(self, message):
        """Update status"""
        if hasattr(self, 'root'):
            self.root.after(0, lambda: self.status_label.config(text=message))
    
    def update_doc_count(self):
        """Update document count"""
        count = self.doc_listbox.size()
        self.doc_count_label.config(text=f"Documents: {count}")
    
    def upload_document(self):
        """Handle upload"""
        if not self.models_loaded:
            messagebox.showwarning("Please Wait", "Models still loading.")
            return
        
        file_paths = filedialog.askopenfilenames(
            title="Select PDFs",
            filetypes=[("PDF files", "*.pdf"), ("All files", "*.*")]
        )
        
        if file_paths:
            for file_path in file_paths:
                threading.Thread(target=self.process_document, args=(file_path,), daemon=True).start()
    
    def process_document(self, file_path):
        """Process document"""
        try:
            filename = os.path.basename(file_path)
            self.update_status(f"📄 Processing {filename}...")
            chunks = self.add_document(file_path)
            
            self.root.after(0, lambda: self.doc_listbox.insert('end', f"📄 {filename} ({chunks} chunks)"))
            self.root.after(0, self.update_doc_count)
            self.root.after(0, lambda: self.delete_btn.config(state='normal'))
            self.update_status(f"✓ Added {filename}")
            
            # Show confirmation message
            self.root.after(0, lambda: messagebox.showinfo("Document Added", 
                f"'{filename}' has been successfully uploaded.\n\nExtracted {chunks} text chunks for analysis."))
        except Exception as e:
            self.root.after(0, lambda: messagebox.showerror("Error", f"Failed to process document:\n{str(e)}"))
    
    def delete_document(self):
        """Delete selected document from the list and vector store"""
        selection = self.doc_listbox.curselection()
        
        if not selection:
            messagebox.showwarning("No Selection", "Please select a document to remove.")
            return
        
        # Get the selected item text
        selected_idx = selection[0]
        selected_text = self.doc_listbox.get(selected_idx)
        
        # Extract filename from the listbox text (format: "📄 filename.pdf (X chunks)")
        # Remove the emoji and extract just the filename
        filename = selected_text.replace("📄 ", "").split(" (")[0]
        
        # Confirm deletion
        confirm = messagebox.askyesno("Confirm Deletion", 
            f"Are you sure you want to remove '{filename}'?\n\nThis will delete the document from the database.")
        
        if not confirm:
            return
        
        try:
            # Remove from ChromaDB - get all IDs that contain this filename
            all_data = self.collection.get()
            ids_to_delete = []
            
            for i, metadata in enumerate(all_data['metadatas']):
                if metadata.get('source') == filename:
                    ids_to_delete.append(all_data['ids'][i])
            
            if ids_to_delete:
                self.collection.delete(ids=ids_to_delete)
            
            # Remove from listbox
            self.doc_listbox.delete(selected_idx)
            self.update_doc_count()
            
            # Rebuild BM25 index
            self.rebuild_bm25_index()
            
            # Disable delete button if no more documents
            if self.doc_listbox.size() == 0:
                self.delete_btn.config(state='disabled')
            
            self.update_status(f"✓ Removed {filename}")
            
            # Show confirmation
            messagebox.showinfo("Document Removed", 
                f"'{filename}' has been successfully removed.\n\n{len(ids_to_delete)} chunks deleted from the database.")
            
        except Exception as e:
            messagebox.showerror("Error", f"Failed to remove document:\n{str(e)}")

    def add_document(self, file_path):
        """Add document"""
        text = self.extract_text_from_pdf(file_path)
        chunks = self.smart_chunk_text(text)
        
        for i, chunk in enumerate(chunks):
            embedding = self.embedder.encode(chunk).tolist()
            self.collection.add(
                embeddings=[embedding],
                documents=[chunk],
                metadatas=[{
                    "source": os.path.basename(file_path),
                    "chunk_id": i,
                    "page": i // 3
                }],
                ids=[f"{file_path}_{i}"]
            )
        
        self.rebuild_bm25_index()
        return len(chunks)
    
    def extract_text_from_pdf(self, file_path):
        """Extract from PDF"""
        text = ""
        with open(file_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            for page in reader.pages:
                text += page.extract_text() + "\n"
        return text
    
    def smart_chunk_text(self, text, chunk_size=600, overlap=200):
        """Smart chunking"""
        text = re.sub(r'\s+', ' ', text).strip()
        sentences = re.split(r'(?<=[.!?])\s+', text)
        
        chunks = []
        current_chunk = []
        current_length = 0
        
        for sentence in sentences:
            words = sentence.split()
            sentence_length = len(words)
            
            if current_length + sentence_length > chunk_size and current_chunk:
                chunk_text = ' '.join(current_chunk)
                if len(chunk_text.strip()) > 100:
                    chunks.append(chunk_text)
                
                overlap_sentences = []
                overlap_length = 0
                for s in reversed(current_chunk):
                    if overlap_length + len(s.split()) <= overlap:
                        overlap_sentences.insert(0, s)
                        overlap_length += len(s.split())
                    else:
                        break
                
                current_chunk = overlap_sentences
                current_length = overlap_length
            
            current_chunk.append(sentence)
            current_length += sentence_length
        
        if current_chunk:
            chunk_text = ' '.join(current_chunk)
            if len(chunk_text.strip()) > 100:
                chunks.append(chunk_text)
        
        return chunks
    
    def advanced_hybrid_search(self, question, n_results=15):
        """Advanced hybrid search"""
        # Check if collection has documents
        collection_data = self.collection.get()
        if not collection_data['documents'] or len(collection_data['documents']) == 0:
            return []
        
        question_embedding = self.embedder.encode(question).tolist()
        vector_results = self.collection.query(
            query_embeddings=[question_embedding],
            n_results=n_results
        )
        
        combined_docs = {}
        k = 60
        
        for rank, (doc, metadata) in enumerate(zip(vector_results['documents'][0], 
                                                     vector_results['metadatas'][0])):
            doc_key = doc[:150]
            if doc_key not in combined_docs:
                combined_docs[doc_key] = {
                    'doc': doc, 
                    'metadata': metadata, 
                    'score': 0
                }
            combined_docs[doc_key]['score'] += 1 / (k + rank)
        
        if self.bm25:
            tokenized_query = question.lower().split()
            bm25_scores = self.bm25.get_scores(tokenized_query)
            top_bm25_indices = np.argsort(bm25_scores)[-n_results:][::-1]
            
            for rank, idx in enumerate(top_bm25_indices):
                if idx < len(self.bm25_corpus):
                    doc = self.bm25_corpus[idx]
                    doc_key = doc[:150]
                    
                    if doc_key not in combined_docs:
                        all_docs = self.collection.get()
                        if idx < len(all_docs['metadatas']):
                            metadata = all_docs['metadatas'][idx]
                            combined_docs[doc_key] = {
                                'doc': doc, 
                                'metadata': metadata, 
                                'score': 0
                            }
                    
                    if doc_key in combined_docs:
                        combined_docs[doc_key]['score'] += 1 / (k + rank)
        
        sorted_docs = sorted(combined_docs.values(), key=lambda x: x['score'], reverse=True)
        return sorted_docs[:n_results]
    
    def rerank_documents(self, question, doc_results, top_k=5):
        """Rerank documents"""
        if not doc_results:
            return []
        
        documents = [d['doc'] for d in doc_results]
        pairs = [[question, doc] for doc in documents]
        scores = self.reranker.predict(pairs)
        
        for i, doc_result in enumerate(doc_results):
            doc_result['rerank_score'] = float(scores[i])
            doc_result['final_score'] = (
                0.3 * doc_result['score'] +
                0.7 * doc_result['rerank_score']
            )
        
        reranked = sorted(doc_results, key=lambda x: x['final_score'], reverse=True)
        return reranked[:top_k]
    
    def generate_answer(self, question, contexts, mode='answer'):
        """Generate answer using the AI model"""
        # Get current RAG mode
        current_mode = self.rag_mode.get()
        
        # Use different number of contexts based on mode
        if current_mode == "basic":
            num_contexts = 2  # Basic: faster, 2 contexts
        else:
            num_contexts = 3  # Advanced: more detailed, 3 contexts
        
        context_text = "\n\n".join([c['doc'] for c in contexts[:num_contexts]])
        
        if mode == 'summarize':
            prompt = f"""<|im_start|>system
You are a professional assistant providing clear, well-structured summaries.<|im_end|>
<|im_start|>user
Provide a clear and professional summary of the following content. Use proper paragraphs and avoid bullet points or numbered lists. Write in a natural, flowing narrative style.

Content:
{context_text}

Summary:<|im_end|>
<|im_start|>assistant
"""
        else:
            prompt = f"""<|im_start|>system
You are a professional assistant providing clear, concise answers. Write in complete sentences and paragraphs, not bullet points or lists.<|im_end|>
<|im_start|>user
Based on the following context, answer the question in a clear, professional manner. Write your answer in flowing paragraphs without using bullet points, numbered lists, or special formatting.

Context:
{context_text}

Question: {question}

Answer:<|im_end|>
<|im_start|>assistant
"""
        
        # Generate with llama.cpp - Optimized for speed
        output = self.llm(
            prompt,
            max_tokens=300,  # Reduced for faster generation
            temperature=0.7,
            top_p=0.9,
            repeat_penalty=1.1,
            stop=["<|im_end|>", "<|im_start|>"],
            top_k=40  # Limit sampling for faster generation
        )
        
        answer = output['choices'][0]['text'].strip()
        return answer
    
    def display_contexts(self, contexts, question):
        """Display contexts with highlighting"""
        self.context_text.delete('1.0', 'end')
        
        for i, ctx in enumerate(contexts, 1):
            source_text = f"\n{'─'*50}\n"
            source_text += f"📄 Source {i}: {ctx['metadata']['source']}\n"
            source_text += f"📍 Page ~{ctx['metadata']['page']}\n"
            source_text += f"{'─'*50}\n\n"
            
            self.context_text.insert('end', source_text, 'source')
            
            doc_text = ctx['doc']
            keywords = [w.lower() for w in question.split() if len(w) > 3]
            
            last_pos = 0
            for match in re.finditer(r'\b\w+\b', doc_text):
                word = match.group()
                start, end = match.span()
                
                self.context_text.insert('end', doc_text[last_pos:start])
                
                if word.lower() in keywords:
                    self.context_text.insert('end', word, 'highlight')
                else:
                    self.context_text.insert('end', word)
                
                last_pos = end
            
            self.context_text.insert('end', doc_text[last_pos:] + '\n\n')
    
    def ask_question_thread(self, mode='answer'):
        """Handle question"""
        question = self.question_entry.get('1.0', 'end-1c').strip()
        
        if mode == 'summarize':
            if self.doc_listbox.size() == 0:
                messagebox.showwarning("No Documents", "Upload documents first.")
                return
            question = "Provide a comprehensive summary"
        elif not question:
            messagebox.showwarning("Input Required", "Enter a question.")
            return
        
        if not self.models_loaded:
            messagebox.showwarning("Please Wait", "Models still loading.")
            return
        
        self.ask_btn.config(state='disabled')
        self.summary_btn.config(state='disabled')
        self.answer_text.delete('1.0', 'end')
        self.context_text.delete('1.0', 'end')
        
        self.answer_text.insert('1.0', "🔍 Analyzing your question...\n\nPlease wait...")
        self.update_status("🤔 Processing your question...")
        
        threading.Thread(target=self.process_question, args=(question, mode), daemon=True).start()
    
    def process_question(self, question, mode):
        """Process question"""
        try:
            # Get current RAG mode
            current_mode = self.rag_mode.get()
            
            if current_mode == "basic":
                # Basic mode: Faster, fewer results
                doc_results = self.advanced_hybrid_search(question, n_results=8)
                top_k = 3
                mode_label = "⚡ Basic"
            else:
                # Advanced mode: More comprehensive
                doc_results = self.advanced_hybrid_search(question, n_results=15)
                top_k = 5
                mode_label = "🎯 Advanced"
            
            if not doc_results:
                self.root.after(0, lambda: self.answer_text.delete('1.0', 'end'))
                self.root.after(0, lambda: self.answer_text.insert('1.0', 
                    "❌ No documents found. Upload PDFs first."))
                return
            
            # Rerank based on mode
            reranked_contexts = self.rerank_documents(question, doc_results, top_k=top_k)
            self.root.after(0, lambda: self.display_contexts(reranked_contexts, question))
            
            answer = self.generate_answer(question, reranked_contexts, mode)
            
            # Format enterprise-grade response
            result = "┌" + "─" * 78 + "┐\n"
            result += "│  ANSWER                                                                      │\n"
            result += "└" + "─" * 78 + "┘\n\n"
            
            result += f"{answer}\n\n"
            
            result += "┌" + "─" * 78 + "┐\n"
            result += "│  REFERENCES                                                                  │\n"
            result += "└" + "─" * 78 + "┘\n\n"
            
            for i, ctx in enumerate(reranked_contexts, 1):
                source = ctx['metadata']['source']
                page = ctx['metadata']['page']
                result += f"  [{i}] {source}\n"
                result += f"      Page: {page}\n\n"
            
            self.root.after(0, lambda: self.answer_text.delete('1.0', 'end'))
            self.root.after(0, lambda: self.answer_text.insert('1.0', result))
            self.update_status(f"✓ Answer generated ({mode_label} mode)!")
            
        except Exception as e:
            error_msg = f"❌ Error: {str(e)}"
            self.root.after(0, lambda: self.answer_text.delete('1.0', 'end'))
            self.root.after(0, lambda: self.answer_text.insert('1.0', error_msg))
            self.update_status(f"❌ Error: {str(e)}")
        finally:
            self.root.after(0, lambda: self.ask_btn.config(state='normal'))
            self.root.after(0, lambda: self.summary_btn.config(state='normal'))
    
    def run(self):
        """Start"""
        self.root.mainloop()


def check_license_and_run():
    """Check license/trial status before running the application"""
    # Initialize license manager
    license_manager = LicenseManager()
    
    # Get overall status
    can_run, is_trial, days_remaining, message = license_manager.get_status()
    
    if can_run:
        # Either licensed or valid trial - run the app
        trial_info = (is_trial, days_remaining)
        app = DocumentQAApp(trial_info=trial_info)
        app.run()
    else:
        # Trial expired or no license - show license dialog
        # Create a hidden root window for the dialog
        root = tk.Tk()
        root.withdraw()  # Hide the main window
        
        # Show license dialog
        dialog = LicenseDialog(root, license_manager, days_remaining=0, is_expired=True)
        result = dialog.show()
        
        if result:
            # License activated or user chose to continue (shouldn't happen if expired)
            root.destroy()
            can_run, is_trial, days_remaining, message = license_manager.get_status()
            if can_run:
                trial_info = (is_trial, days_remaining)
                app = DocumentQAApp(trial_info=trial_info)
                app.run()
        else:
            # User chose to exit
            root.destroy()
            sys.exit(0)


if __name__ == "__main__":
    check_license_and_run()